// Path: app/membership/login/page.tsx
import type { Metadata } from 'next';
import { PageHero } from '@/components/Page';
import { Card } from '@/components/ui';
import LoginForm from './LoginForm';

export const metadata: Metadata = { title: 'Member Login | MOA' };

export default async function MemberLoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;
  const notice =
    error === 'confirm'
      ? 'We could not complete the confirmation automatically. If you already clicked the link in your email, just log in below.'
      : undefined;

  return (
    <>
      <PageHero
        title="Member login"
        subtitle="Log in to see your membership status, member card and certificate number."
      />
      <div className="container py-16">
        <div className="mx-auto max-w-md">
          <Card>
            <LoginForm notice={notice} />
          </Card>
        </div>
      </div>
    </>
  );
}