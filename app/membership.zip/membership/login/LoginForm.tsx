// Path: app/membership/login/LoginForm.tsx
'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { ErrorNote, SubmitButton, inputCls, labelCls, linkCls } from '@/components/form-ui';
import { memberLogin } from '../auth-actions';

export default function LoginForm({ notice }: { notice?: string }) {
  const [state, formAction, pending] = useActionState(memberLogin, undefined);

  return (
    <form action={formAction} className="grid gap-5">
      {notice && !state?.error && (
        <p className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">{notice}</p>
      )}

      <label className={labelCls}>
        Email
        <input name="email" type="email" required autoComplete="email" className={inputCls} />
      </label>
      <label className={labelCls}>
        Password
        <input name="password" type="password" required autoComplete="current-password" className={inputCls} />
      </label>

      {state?.error && <ErrorNote>{state.error}</ErrorNote>}

      <SubmitButton pending={pending} idle="Log in" busy="Signing in…" />

      <div className="grid gap-1 text-center text-sm text-muted">
        <p>
          Applied but no account yet?{' '}
          <Link href="/membership/signup" className={linkCls}>
            Create your account
          </Link>
        </p>
        <p>
          Started an application but didn’t finish?{' '}
          <Link href="/membership/apply/resume" className={linkCls}>
            Continue application
          </Link>
        </p>
        <p>
          Not a member yet?{' '}
          <Link href="/membership/apply" className={linkCls}>
            Apply for membership
          </Link>
        </p>
      </div>
    </form>
  );
}