// Path: app/membership/signup/SignupForm.tsx
'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { ErrorNote, SubmitButton, inputCls, labelCls, linkCls } from '@/components/form-ui';
import { memberSignup } from '../auth-actions';

export default function SignupForm() {
  const [state, formAction, pending] = useActionState(memberSignup, undefined);

  if (state?.success) {
    return (
      <div className="grid gap-4 text-center">
        <h2 className="font-display text-xl font-bold">Almost done</h2>
        <p className="rounded-xl bg-tint px-4 py-3 text-sm font-semibold text-brand-dark">{state.success}</p>
        <Link href="/membership/login" className={linkCls}>
          Go to login →
        </Link>
      </div>
    );
  }

  return (
    <form action={formAction} className="grid gap-5">
      <label className={labelCls}>
        Registration number
        <input
          name="application_no"
          required
          placeholder="MOA-2026-00001"
          autoCapitalize="characters"
          className={`${inputCls} uppercase`}
        />
      </label>
      <label className={labelCls}>
        Email used in the application
        <input name="email" type="email" required autoComplete="email" className={inputCls} />
      </label>
      <label className={labelCls}>
        Password
        <input
          name="password"
          type="password"
          required
          minLength={8}
          autoComplete="new-password"
          placeholder="At least 8 characters"
          className={inputCls}
        />
      </label>
      <label className={labelCls}>
        Confirm password
        <input name="confirm" type="password" required minLength={8} autoComplete="new-password" className={inputCls} />
      </label>

      {state?.error && <ErrorNote>{state.error}</ErrorNote>}

      <SubmitButton pending={pending} idle="Create account" busy="Creating account…" />

      <div className="grid gap-1 text-center text-sm text-muted">
        <p>
          Already have an account?{' '}
          <Link href="/membership/login" className={linkCls}>
            Log in
          </Link>
        </p>
        <p>
          Haven’t applied yet?{' '}
          <Link href="/membership/apply" className={linkCls}>
            Apply for membership
          </Link>
        </p>
      </div>
    </form>
  );
}